// Turns typed or dictated text into { kind, title, due }.
// Understands: "add to task ...", "remind me to ...", "note: ...",
// "tomorrow 5pm", "in 20 minutes", "on friday at 7:30", "25 oct", "25/10", "tonight".
(function (root) {
  const MONTHS = ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
  const DAYS = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];

  function parse(input, now) {
    now = now ? new Date(now) : new Date();
    let t = ' ' + String(input || '').replace(/\s+/g, ' ').trim() + ' ';
    let kind = 'task';

    const cut = (re, fn) => {
      const m = t.match(re);
      if (!m) return null;
      t = t.slice(0, m.index) + ' ' + t.slice(m.index + m[0].length);
      if (fn) fn(m);
      return m;
    };

    // Command words at the start or end
    cut(/^\s*(please\s+)?(add|put|save)\s+(this\s+|it\s+)?(to|in|into)\s+(my\s+)?(notes?)\b[\s:,\-]*/i, () => kind = 'note') ||
    cut(/^\s*(please\s+)?(add|put|save)\s+(this\s+|it\s+)?(to|in|into)\s+(my\s+)?(tasks?|to-?dos?|to do( list)?|reminders?)\b[\s:,\-]*/i) ||
    cut(/^\s*(add|new|create|take|make)\s+(a\s+)?note\b[\s:,\-]*/i, () => kind = 'note') ||
    cut(/^\s*note\b[\s:,\-]+/i, () => kind = 'note') ||
    cut(/^\s*(add|new|create)\s+(a\s+)?(task|to-?do|reminder)\b[\s:,\-]*/i) ||
    cut(/^\s*(task|to-?do)\b[\s:,\-]+/i) ||
    cut(/^\s*remind me( to)?\b\s*/i);
    cut(/[\s,.\-]*(add|put|save)\s+(it|this)?\s*(to|in|into)\s+(my\s+)?notes?\s*[.!]?\s*$/i, () => kind = 'note') ||
    cut(/[\s,.\-]*(add|put|save)\s+(it|this)?\s*(to|in|into)\s+(my\s+)?(tasks?|to-?dos?|reminders?)\s*[.!]?\s*$/i);

    let date = null;   // Date at midnight
    let hour = null, min = 0;
    let exact = null;  // absolute Date for "in 20 minutes"

    // Relative: in 20 minutes / in an hour / in 2 days
    cut(/\bin\s+(\d+|an?|half an?)\s*(minutes?|mins?|hours?|hrs?|days?)\b/i, m => {
      const n = /half/i.test(m[1]) ? 0.5 : /^an?$/i.test(m[1]) ? 1 : +m[1];
      const u = m[2].toLowerCase();
      const ms = u.startsWith('d') ? 864e5 : u.startsWith('h') ? 36e5 : 6e4;
      exact = new Date(now.getTime() + n * ms);
    });

    const day0 = d => new Date(d.getFullYear(), d.getMonth(), d.getDate());
    const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
    const today = day0(now);

    cut(/\b(the\s+)?day after tomorrow\b/i, () => date = addDays(today, 2)) ||
    cut(/\btomorrow\b/i, () => date = addDays(today, 1)) ||
    cut(/\btonight\b/i, () => { date = today; if (hour === null) { hour = 21; } }) ||
    cut(/\btoday\b/i, () => date = today);

    if (!date) cut(/\b(on\s+|this\s+|next\s+|coming\s+)?(sun|mon|tue|tues|wed|thu|thur|thurs|fri|sat)(day|nesday|sday|urday|rsday)?\b/i, m => {
      const idx = DAYS.findIndex(d => d.startsWith(m[2].toLowerCase().slice(0, 3)));
      let diff = (idx - today.getDay() + 7) % 7;
      if (diff === 0) diff = 7;
      if (/next/i.test(m[1] || '') && diff < 7) diff += 0; // "next friday" = the coming one
      date = addDays(today, diff);
    });

    const mon = '(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\\.?';
    const setDM = (d, mIdx, y) => {
      let yr = y ? (+y < 100 ? 2000 + +y : +y) : today.getFullYear();
      let c = new Date(yr, mIdx, d);
      if (!y && c < today) c = new Date(yr + 1, mIdx, d);
      date = c;
    };
    if (!date) cut(new RegExp('\\b(on\\s+)?(\\d{1,2})(st|nd|rd|th)?\\s+(of\\s+)?' + mon + '(\\s+(\\d{4}))?\\b', 'i'),
      m => setDM(+m[2], MONTHS.indexOf(m[5].toLowerCase().slice(0, 3)), m[8]));
    if (!date) cut(new RegExp('\\b(on\\s+)?' + mon + '\\s+(\\d{1,2})(st|nd|rd|th)?(,?\\s+(\\d{4}))?\\b', 'i'),
      m => setDM(+m[3], MONTHS.indexOf(m[2].toLowerCase().slice(0, 3)), m[6]));
    if (!date) cut(/\b(on\s+)?(\d{1,2})[\/\-](\d{1,2})([\/\-](\d{2,4}))?\b/, m => {
      const d = +m[2], mo = +m[3] - 1;
      if (d >= 1 && d <= 31 && mo >= 0 && mo <= 11) setDM(d, mo, m[5]);
    });

    // Times
    const ap = '(a\\.?\\s?m\\.?|p\\.?\\s?m\\.?)';
    const applyAP = (h, s) => {
      if (!s) return h;
      const pm = /p/i.test(s);
      if (pm && h < 12) return h + 12;
      if (!pm && h === 12) return 0;
      return h;
    };
    let gotTime =
      cut(new RegExp('\\b(at|by|@)?\\s*(\\d{1,2})[:.](\\d{2})\\s*' + ap + '?(?=\\W|$)', 'i'), m => {
        hour = applyAP(+m[2], m[4]); min = +m[3];
        if (!m[4] && hour < 7) hour += 12;
      }) ||
      cut(new RegExp('\\b(at|by|@)?\\s*(\\d{1,2})\\s*' + ap + '(?=\\W|$)', 'i'), m => {
        hour = applyAP(+m[2], m[3]); min = 0;
      }) ||
      cut(/\b(at|by)\s+(\d{1,2})\s*(o'?clock)?\b/i, m => {
        hour = +m[2]; min = 0; if (hour < 7) hour += 12;
      }) ||
      cut(/\b(at\s+)?noon\b/i, () => { hour = 12; min = 0; }) ||
      cut(/\b(at\s+)?midnight\b/i, () => { hour = 23; min = 59; });

    if (!gotTime) {
      cut(/\b(in the\s+|this\s+)?morning\b/i, () => { hour = 9; min = 0; }) ||
      cut(/\b(in the\s+|this\s+)?afternoon\b/i, () => { hour = 14; min = 0; }) ||
      cut(/\b(in the\s+|this\s+)?evening\b/i, () => { hour = 18; min = 0; }) ||
      cut(/\b(at\s+)?night\b/i, () => { hour = 21; min = 0; });
    }
    if (hour !== null && hour > 23) hour = null;

    let due = null;
    if (exact) due = exact;
    else if (date || hour !== null) {
      const base = date || today;
      due = new Date(base.getFullYear(), base.getMonth(), base.getDate(), hour === null ? 9 : hour, min);
      if (!date && due <= now) due = new Date(due.getTime() + 864e5);
    }

    let title = t.replace(/\s+/g, ' ')
      .replace(/\s+(on|at|by|for|this|next)\s*$/i, '')
      .replace(/^\s*(to|that|and)\s+/i, '')
      .replace(/^[\s,.:;\-]+|[\s,.:;\-]+$/g, '')
      .trim();
    if (title) title = title[0].toUpperCase() + title.slice(1);
    if (kind === 'note') due = null;
    return { kind, title, due: due ? due.getTime() : null };
  }

  root.parseEntry = parse;
  if (typeof module !== 'undefined') module.exports = parse;
})(typeof window !== 'undefined' ? window : globalThis);
