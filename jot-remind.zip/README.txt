JOT & REMIND - free offline task & reminder app

PUT IT ONLINE (free, 2 minutes, one time):
1. On a computer, open https://app.netlify.com/drop
2. Drag this whole "jot-remind" folder onto the page (free sign-up if asked).
3. You get a link like https://something.netlify.app - open it on your phone.
(Alternative: GitHub Pages, also free.)

ON YOUR PHONE:
- Android (Chrome): open the link > menu (3 dots) > "Add to Home screen / Install app".
- iPhone (Safari, iOS 16.4+): Share > "Add to Home Screen". Open it from the home-screen icon,
  then tap Allow for notifications.
- Tap "Allow" for notifications. Use Settings > "Test notification" to check.

After the first open it works offline. Your tasks stay on your phone only.
Use Settings > "Back up data" now and then, since clearing browser data erases them.
